"""Tests for the sliding-window rate limiter (.kiro/specs/rate-limiter/)."""
import time

from fastapi import FastAPI
from fastapi.testclient import TestClient

from src.api.rate_limiter import InMemoryStore, RateLimitMiddleware


# ------------------------------- unit: store ------------------------------- #
def test_inmemory_allows_then_blocks():
    s = InMemoryStore()
    now = time.time()
    allowed = [s.hit("k", now, window=60, max_=4)[0] for _ in range(4)]
    assert all(allowed)                     # first 4 allowed
    assert s.hit("k", now, window=60, max_=4)[0] is False   # 5th blocked


def test_inmemory_sliding_window_expiry():
    s = InMemoryStore()
    base = 1000.0
    for i in range(4):
        s.hit("k", base + i, window=10, max_=4)
    # at t=base+4 the window is full -> blocked
    assert s.hit("k", base + 4, window=10, max_=4)[0] is False
    # jump past the window so the early entries expire -> allowed again
    assert s.hit("k", base + 20, window=10, max_=4)[0] is True


def test_remaining_decrements():
    s = InMemoryStore()
    now = time.time()
    _, r1, _ = s.hit("k", now, 60, 3)
    _, r2, _ = s.hit("k", now, 60, 3)
    assert r1 == 2 and r2 == 1


# --------------------------- integration: middleware ----------------------- #
def _app(monkeypatch, max_=3):
    monkeypatch.setenv("RATE_LIMIT_MAX", str(max_))
    monkeypatch.setenv("RATE_LIMIT_WINDOW_S", "60")
    monkeypatch.setenv("RATE_LIMIT_ENABLED", "true")
    app = FastAPI()
    app.add_middleware(RateLimitMiddleware, store=InMemoryStore())

    @app.get("/health")
    def health():
        return {"status": "ok"}

    @app.get("/api/v1/ping")
    def ping():
        return {"pong": True}

    return TestClient(app)


def test_429_after_cap_with_headers(monkeypatch):
    c = _app(monkeypatch, max_=3)
    for _ in range(3):
        ok = c.get("/api/v1/ping")
        assert ok.status_code == 200
        assert ok.headers["X-RateLimit-Limit"] == "3"
        assert "X-RateLimit-Remaining" in ok.headers
    blocked = c.get("/api/v1/ping")
    assert blocked.status_code == 429
    assert blocked.headers["X-RateLimit-Remaining"] == "0"
    assert "Retry-After" in blocked.headers
    assert "X-RateLimit-Reset" in blocked.headers


def test_health_is_exempt(monkeypatch):
    c = _app(monkeypatch, max_=1)
    c.get("/api/v1/ping")            # consume the only token
    assert c.get("/api/v1/ping").status_code == 429   # now limited
    for _ in range(5):               # health must never be limited
        assert c.get("/health").status_code == 200
