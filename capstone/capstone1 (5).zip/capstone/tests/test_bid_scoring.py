"""Tests for the Bid/No-Bid scoring agent (.kiro/specs/bid-no-bid/)."""
from src.agents.bid_scoring import (
    score_bid, analyze_opportunity, _normalise, CRITERIA, DEFAULT_WEIGHTS)


# ------------------------------- scoring core ------------------------------ #
def test_high_scores_recommend_bid():
    r = score_bid({k: 90 for k in CRITERIA})
    assert r.recommendation == "BID" and r.score >= 70


def test_low_scores_recommend_nobid():
    r = score_bid({k: 20 for k in CRITERIA})
    assert r.recommendation == "NO-BID" and r.score < 45


def test_mid_scores_recommend_review():
    r = score_bid({k: 55 for k in CRITERIA})
    assert r.recommendation == "REVIEW"


def test_threshold_boundaries():
    assert score_bid({k: 70 for k in CRITERIA}).recommendation == "BID"      # ==70
    assert score_bid({k: 45 for k in CRITERIA}).recommendation == "REVIEW"   # ==45
    assert score_bid({k: 44 for k in CRITERIA}).recommendation == "NO-BID"


def test_breakdown_sums_to_total():
    r = score_bid({k: 60 for k in CRITERIA})
    assert round(sum(r.breakdown.values()), 2) == r.score


def test_missing_criteria_default_to_neutral():
    r = score_bid({"solution_fit": 100})   # others default to 50
    assert 45 <= r.score <= 100 and set(r.breakdown) == set(CRITERIA)


def test_scores_are_clamped():
    r = score_bid({k: 999 for k in CRITERIA})
    assert r.score <= 100
    r2 = score_bid({k: -50 for k in CRITERIA})
    assert r2.score >= 0


def test_weights_normalised():
    w = _normalise({k: 2 for k in CRITERIA})   # equal, non-unit
    assert abs(sum(w.values()) - 1.0) < 1e-6


def test_zero_weights_fall_back_to_equal():
    w = _normalise({k: 0 for k in CRITERIA})
    assert abs(sum(w.values()) - 1.0) < 1e-6


def test_rationale_present():
    r = score_bid({k: 80 for k in CRITERIA})
    assert "score" in r.rationale.lower()


# ------------------------------- analyzer ---------------------------------- #
def test_analyze_is_deterministic():
    txt = "Healthcare RFP with $2M budget, mandatory HIPAA compliance, deadline within 30 days."
    a1 = analyze_opportunity(txt)
    a2 = analyze_opportunity(txt)
    assert a1["suggested_scores"] == a2["suggested_scores"]
    assert a1["signals"] == a2["signals"]


def test_analyze_scores_in_range_and_signals():
    txt = "Strategic long-term partnership. Scope and requirements defined. Budget provided."
    a = analyze_opportunity(txt)
    assert all(0 <= v <= 100 for v in a["suggested_scores"].values())
    assert len(a["signals"]) >= 1


def test_analyze_detects_domain():
    a = analyze_opportunity("Crop yield and soil irrigation program for farms.")
    assert a["detected_domain"] == "Agriculture"


def test_analyze_empty_text_neutral():
    a = analyze_opportunity("   ")
    assert a["suggested_scores"] == {k: 50.0 for k in CRITERIA}
    assert a["signals"] == []


def test_score_from_analyzed_opportunity():
    a = analyze_opportunity("Finance loan underwriting platform, strategic, budget stated, scope defined.")
    r = score_bid(a["suggested_scores"])
    assert r.recommendation in ("BID", "REVIEW", "NO-BID")
