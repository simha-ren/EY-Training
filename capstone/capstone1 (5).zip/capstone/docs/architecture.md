# Architecture

ProposalForge Pro is a domain-aware Retrieval-Augmented Generation (RAG) assistant.
It ships two entry points over one shared codebase:

- **Streamlit UI** (`src/ui/app_prod.py`) — the production frontend.
- **FastAPI service** (`src/api/api_server.py`) — REST API, webhooks, `/health`, `/metrics`.

A second, simpler UI (`src/ui/app.py`) drives the five-agent demo loop through
`src/orchestrator/engine.py` and is useful for understanding the routing/RAG core.

## Repository layout

```
capstone/
├─ src/
│  ├─ agents/        LLM clients + generation/suggestion agents
│  │                 (llm, llm_backend, claude_llm, groq_llm, generation, suggest, agents)
│  ├─ orchestrator/  control loop + routing + async jobs
│  │                 (engine, router, pipeline, job_store, service_bus, approval_workflow)
│  ├─ retrieval/     vector + RAG (retriever, store, ingestion, ragas_eval)
│  ├─ common/        shared services (config, guardrails, auth, audit_logger, metrics,
│  │                 observability, tracing, notifications, chat_store, file_processor,
│  │                 test_runner, report_generator)
│  ├─ api/           FastAPI app (api_server.py)
│  └─ ui/            Streamlit frontends (app_prod.py, app.py)
├─ infra/            Dockerfiles, docker-compose, Azure IaC (Bicep), nginx, k8s, monitoring
├─ tests/            unit + integration + load (tests/load)
├─ docs/             this file, decisions.md, and the original design notes
├─ data/ domains/ eval/ .streamlit/   runtime data + per-domain config (repo root)
├─ .github/workflows/  CI (ci.yml) and CI/CD to Azure (azure.yml)
├─ requirements.txt  .env.example  .gitignore  pytest.ini
└─ worker.py start.py evaluate.py   entry-point launchers
```

`src` is a proper package; everything imports as `src.<subpackage>.<module>`. Runtime
data (`data/`, `domains/`, `eval/`, `.streamlit/`) lives at the repo root; `src/common/config.py`
resolves the root as `Path(__file__).resolve().parents[2]`.

## Request flow (orchestrator)

`Engine.ask()` in `src/orchestrator/engine.py` runs the control loop:

1. **Route** — `DomainRouter` (`router.py`) scores the query against each domain by
   blending TF-IDF centroid similarity (from the retrieval store) with per-domain
   `routing_keywords`. Thresholds in `config.py`: `ROUTE_CONFIDENT=0.55`,
   `ROUTE_AMBIGUOUS=0.28`. Above confident → route silently; between → suggest a
   domain chip; below → ask the user to pick.
2. **Guardrail refuse** — out-of-scope requests are declined per the domain's policy.
3. **Gap detection** — missing mandatory details trigger a clarifying question.
4. **Retrieve** — namespace-isolated retrieval within the chosen domain (`store.py`).
5. **Compose** — a grounded answer is generated (`generation.py` + an LLM client).
6. **Suggest** — follow-ups and cross-domain hints (`suggest.py`).

## LLM backends

`src/agents/llm_backend.py::get_llm_client()` selects a backend at runtime:

1. **Groq** (`groq_llm.py`) if `GROQ_API_KEY` is set — OpenAI-compatible, recommended
   free/default option.
2. **Claude** (`claude_llm.py`) if `CLAUDE_API_KEY`/`ANTHROPIC_API_KEY` is set.
3. **Local OpenAI-compatible** server via `LLM_BASE_URL` (e.g. Ollama/vLLM).
4. **Offline extractive** fallback — always available, so the app answers even with
   no key configured.

`GroqLLMClient` mirrors the `ClaudeLLMClient` interface exactly, so the two are
drop-in interchangeable.

## Container topology (Azure)

The Azure image (`infra/Dockerfile.azure`) runs three processes behind nginx:

```
        Azure Web App (WEBSITES_PORT = 8080)
                     │
                 nginx :8080         (infra/deploy/nginx.app.conf)
        ┌────────────┴─────────────┐
   /  →  Streamlit :8000       /api/ , /health , /metrics  →  FastAPI :8001
```

`infra/deploy/entrypoint.sh` sets `PYTHONPATH=/app`, launches
`uvicorn src.api.api_server:app` and `streamlit run src/ui/app_prod.py`, then runs
nginx in the foreground. Health checks hit `/health`.

## Observability

Two independent layers, by design:

**Metrics — "how many / how fast" (Prometheus).** `observability.py` emits counters
and histograms (request counts, pipeline latency, active runs, error rates) exposed at
`/metrics`; a shared multiprocess dir aggregates the UI and API processes.
`infra/monitoring/` ships Prometheus config, alert rules, and a Grafana dashboard —
these run via `infra/docker-compose.yml` for **local** development.

**Tracing — "what happened in this one run" (Azure Monitor / LangSmith).**
`tracing.py` turns each pipeline run and every agent into a span carrying latency,
token usage, RAGAS scores, the quality gate, and guardrail hits. `get_tracer()`
auto-selects a backend in priority order: **Azure Monitor (Application Insights) →
LangSmith → Langfuse → no-op**.

**Production default: Azure Monitor.** The single Azure container is the whole
deployment, so there is nothing to scrape Prometheus in production. Instead, the Bicep
template (`infra/deploy/azure/main.bicep`) provisions an Application Insights resource
and injects `APPLICATIONINSIGHTS_CONNECTION_STRING` into the Web App — so tracing and
request telemetry flow to Azure Monitor automatically, with no manual setup. View them
in the Azure portal (Application Insights → Transaction search / Application map).
Prometheus/Grafana remain the local-dev metrics option; LangSmith is an opt-in for
richer LLM-level traces during development (set `LANGCHAIN_TRACING_V2=true` +
`LANGCHAIN_API_KEY`).
