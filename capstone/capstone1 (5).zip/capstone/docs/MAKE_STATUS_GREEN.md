# Make System Status Green — Azure OpenAI + Pinecone + Azure Monitor

Your app deploys via the publish-profile workflow, so the Bicep's automatic wiring
didn't run. The System status panel reads `groq / faiss / none / off` because those
settings aren't on the Web App yet. Add them as **Application settings** on your
existing Web App (no redeploy of code needed — just a restart). ~15 minutes total.

All settings go here:
**Azure portal → App Services → `proposalforge-app` → Settings → Environment variables
→ Application settings → + Add**, then **Apply** and let the app restart.

---

## A. Azure OpenAI  (status: LLM connector → `azure_openai`)

1. Portal → search **Azure OpenAI** → **+ Create**.
   - Same subscription + resource group, a supported region (e.g. East US, Sweden
     Central). Name e.g. `proposalforge-aoai`. Create (takes a few minutes).
   - Note: Azure OpenAI needs to be **enabled on your subscription**. If Create is
     blocked, your sub doesn't have access yet — request it, or skip to keep Groq.
2. Open the resource → **Azure AI Foundry / Model deployments** → **+ Deploy model**
   → pick `gpt-4o-mini` (or `gpt-4o`) → give the **deployment** a name, e.g.
   `gpt-4o-mini` → Deploy.
3. Resource → **Keys and Endpoint** → copy **Endpoint** and **KEY 1**.
4. Add these 4 Application settings on the Web App:

   | Name | Value |
   |---|---|
   | `AZURE_OPENAI_ENDPOINT` | `https://proposalforge-aoai.openai.azure.com` |
   | `AZURE_OPENAI_API_KEY` | your KEY 1 |
   | `AZURE_OPENAI_DEPLOYMENT` | your deployment name (e.g. `gpt-4o-mini`) |
   | `AZURE_OPENAI_API_VERSION` | `2024-06-01` |

The app picks Azure OpenAI first when these are set, so the panel shows
`azure_openai` (online=True).

---

## B. Pinecone  (status: Vector DB → `pinecone`)

1. Go to **app.pinecone.io** → create a free account/project.
2. **Create index**:
   - Name: `proposalforge`
   - **Dimension: `384`**  (must match the embedding model `BAAI/bge-small-en-v1.5`)
   - Metric: `cosine`
   - Serverless (free tier is fine).
3. **API Keys** → copy your key.
4. Add these Application settings on the Web App:

   | Name | Value |
   |---|---|
   | `PINECONE_API_KEY` | your Pinecone key |
   | `PINECONE_INDEX` | `proposalforge` |
   | `VECTOR_BACKEND` | `auto` |
   | `EMBEDDING_MODEL` | `BAAI/bge-small-en-v1.5` |

`auto` uses Pinecone when the key is present, so the panel shows `pinecone`.
(Dimension mismatch is the #1 error — it must be **384** for this embedding model.)

---

## C. Azure Monitor / Application Insights  (status: Tracing → `azure`, Azure Monitor → on)

1. Portal → search **Application Insights** → **+ Create**.
   - Same RG, name e.g. `proposalforge-insights`, Resource Mode **Workspace-based**
     (creates/uses a Log Analytics workspace). Create.
2. Open it → **Overview** → copy the **Connection String**
   (looks like `InstrumentationKey=...;IngestionEndpoint=...`).
3. Add this Application setting on the Web App:

   | Name | Value |
   |---|---|
   | `APPLICATIONINSIGHTS_CONNECTION_STRING` | the full connection string |

The app auto-selects Azure Monitor for tracing when this is set, so the panel shows
tracing `azure` and Azure Monitor `on`. Traces appear in the resource under
**Investigate → Transaction search** / **Application map** within a minute of traffic.

---

## D. Apply + verify

1. On the Web App Environment variables page, click **Apply** — the app restarts
   (~1–2 min; first request after restart is a cold start).
2. Also confirm (once): **Settings → Configuration → General settings → Web sockets: On**
   and `WEBSITES_PORT = 8080`.
3. Open the app → **Tests tab → Refresh status**. You should now see:
   - 🟢 LLM connector: `azure_openai` (online=True)
   - 🟢 Vector DB: `pinecone` (key set: True, index `proposalforge`)
   - 🟢 Tracing: `azure` (enabled=True)
   - 🟢 Azure Monitor: on
4. Cross-check in the browser: `https://proposalforge-app.azurewebsites.net/api/v1/status`
   returns the same JSON.

## E. Verify end-to-end telemetry
- **Azure Monitor:** make a query in the app → portal → your Application Insights →
  **Transaction search** → you see a pipeline trace with per-agent spans.
- **Pinecone:** ingest a document in the app → Pinecone console → index vector count
  rises.
- **Metrics:** open `https://proposalforge-app.azurewebsites.net/metrics` → Prometheus
  text output.

---

### Notes
- You can set all these without a service principal — they're resource creations +
  app settings, which your account can do.
- Keep secrets in Application settings (or Key Vault references), never in the repo.
- If Azure OpenAI isn't available on your subscription, leave section A out: the app
  keeps using Groq and the panel shows `groq` — still fully functional.
