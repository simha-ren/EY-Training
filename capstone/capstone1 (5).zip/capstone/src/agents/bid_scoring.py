"""Bid / No-Bid scoring agent (built via Kiro SDD — .kiro/specs/bid-no-bid/).

Pure-Python, dependency-free. Scores a proposal opportunity across weighted
criteria and returns BID / REVIEW / NO-BID with an explainable breakdown. Also
provides a deterministic opportunity-text analyzer that suggests criterion scores
from detectable signals (no API key required). An online LLM may enrich the
rationale but is never required.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Dict, List, Optional

CRITERIA = ["solution_fit", "win_probability", "strategic_value",
            "feasibility", "risk_profile"]

DEFAULT_WEIGHTS: Dict[str, float] = {
    "solution_fit": 0.30, "win_probability": 0.25, "strategic_value": 0.20,
    "feasibility": 0.15, "risk_profile": 0.10,
}

BID_THRESHOLD = 70.0
NOBID_THRESHOLD = 45.0

_LABEL = {"solution_fit": "solution fit", "win_probability": "win probability",
          "strategic_value": "strategic value", "feasibility": "feasibility",
          "risk_profile": "risk profile"}


@dataclass
class BidResult:
    score: float
    recommendation: str
    breakdown: Dict[str, float]
    weights: Dict[str, float]
    rationale: str
    signals: List[str] = field(default_factory=list)
    detected_domain: str = "General"

    def to_dict(self) -> dict:
        return {"score": self.score, "recommendation": self.recommendation,
                "breakdown": self.breakdown, "weights": self.weights,
                "rationale": self.rationale, "signals": self.signals,
                "detected_domain": self.detected_domain}


def _clamp(v, lo=0.0, hi=100.0) -> float:
    try:
        return max(lo, min(hi, float(v)))
    except (TypeError, ValueError):
        return 50.0


def _normalise(weights: Dict[str, float]) -> Dict[str, float]:
    clean = {k: max(0.0, float(weights.get(k, 0.0))) for k in CRITERIA}
    total = sum(clean.values())
    if total <= 0:                       # degenerate → equal weights
        return {k: round(1.0 / len(CRITERIA), 4) for k in CRITERIA}
    return {k: round(v / total, 4) for k, v in clean.items()}


def _rationale(scores: Dict[str, float], breakdown: Dict[str, float],
               total: float, rec: str) -> str:
    strongest = max(breakdown, key=breakdown.get)
    weakest = min(breakdown, key=breakdown.get)
    verdict = {"BID": "Pursue this opportunity",
               "REVIEW": "Borderline — review before deciding",
               "NO-BID": "Likely decline"}[rec]
    return (f"{verdict} (score {total:.0f}/100). Strongest driver is "
            f"{_LABEL[strongest]} ({scores[strongest]:.0f}); weakest is "
            f"{_LABEL[weakest]} ({scores[weakest]:.0f}).")


def score_bid(scores: Optional[Dict[str, float]] = None,
              weights: Optional[Dict[str, float]] = None) -> BidResult:
    """Compute the weighted Bid score and recommendation. Never raises."""
    scores = scores or {}
    w = _normalise(weights or DEFAULT_WEIGHTS)
    s = {k: _clamp(scores.get(k, 50.0)) for k in CRITERIA}
    breakdown = {k: round(s[k] * w[k], 2) for k in CRITERIA}
    total = round(sum(breakdown.values()), 2)
    rec = "BID" if total >= BID_THRESHOLD else (
        "NO-BID" if total < NOBID_THRESHOLD else "REVIEW")
    return BidResult(score=total, recommendation=rec, breakdown=breakdown,
                     weights=w, rationale=_rationale(s, breakdown, total, rec))


# ------------------------- deterministic text analyzer --------------------- #
_DOMAIN_KW = {
    "Finance": ["loan", "credit", "bank", "invest", "capital", "revenue",
                "portfolio", "fintech", "payment", "underwrit"],
    "Healthcare": ["patient", "clinical", "hospital", "medical", "health",
                   "hipaa", "care", "diagnos", "ehr"],
    "Agriculture": ["crop", "farm", "soil", "irrigation", "yield", "agri",
                    "harvest", "livestock"],
}


def _detect_domain(text: str) -> str:
    t = text.lower()
    best, score = "General", 0
    for d, kws in _DOMAIN_KW.items():
        c = sum(1 for k in kws if k in t)
        if c > score:
            best, score = d, c
    return best


def analyze_opportunity(text: str, llm=None) -> dict:
    """Suggest criterion scores from opportunity text. Deterministic.

    Returns {"suggested_scores", "signals", "detected_domain", "rationale_hint"}.
    """
    t = (text or "").lower()
    signals: List[str] = []
    s = {k: 50.0 for k in CRITERIA}      # neutral baseline

    if not t.strip():
        return {"suggested_scores": s, "signals": [], "detected_domain": "General",
                "rationale_hint": "No opportunity text provided."}

    # Budget / funding stated → better win odds & feasibility
    if re.search(r"\$|\bbudget\b|\bfunding\b|\bcontract value\b", t):
        s["win_probability"] += 12; s["feasibility"] += 8
        signals.append("Budget/funding indicated")

    # Tight deadline / urgency → lower feasibility
    if re.search(r"\bwithin \d+\s*(day|week)|\bdeadline\b|\burgent\b|\bASAP\b", t):
        s["feasibility"] -= 15
        signals.append("Tight timeline")

    # Mandatory certifications / compliance → risk awareness, fit pressure
    if re.search(r"\bmandatory\b|\bmust\b|\biso\b|\bsoc\s?2\b|\bhipaa\b|\bcompliance\b", t):
        s["risk_profile"] -= 10; s["solution_fit"] -= 5
        signals.append("Mandatory compliance/certification")

    # Incumbent / renewal → lower win probability
    if re.search(r"\bincumbent\b|\brenewal\b|\bexisting vendor\b|\bre-?compete\b", t):
        s["win_probability"] -= 15
        signals.append("Incumbent present")

    # Scope clarity → helps solution fit (well-specified) or hurts (vague)
    if re.search(r"\bscope\b|\brequirements?\b|\bdeliverables?\b", t):
        s["solution_fit"] += 8; signals.append("Scope/requirements defined")
    if len(t) < 200:
        s["solution_fit"] -= 8; signals.append("Sparse opportunity detail")

    # Strategic / growth language
    if re.search(r"\bstrategic\b|\blong[- ]term\b|\bpartnership\b|\bexpansion\b", t):
        s["strategic_value"] += 12; signals.append("Strategic/long-term framing")

    # Domain fit
    domain = _detect_domain(t)
    if domain != "General":
        s["solution_fit"] += 8; s["strategic_value"] += 6
        signals.append(f"Domain fit: {domain}")

    s = {k: _clamp(v) for k, v in s.items()}
    hint = f"Detected {len(signals)} signal(s); domain {domain}."
    # Optional online LLM enrichment (never required, scores unchanged)
    if llm is not None and getattr(llm, "online", False) and hasattr(llm, "complete"):
        try:
            r = llm.complete(
                "You are a proposal strategist. One concise sentence.",
                "Summarise the bid attractiveness given these signals: "
                + "; ".join(signals or ["none"]) + f". Domain: {domain}.")
            if r:
                hint = r.strip()
        except Exception:
            pass
    return {"suggested_scores": s, "signals": signals,
            "detected_domain": domain, "rationale_hint": hint}
