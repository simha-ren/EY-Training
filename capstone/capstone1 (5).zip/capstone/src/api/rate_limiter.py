"""Sliding-window API rate limiter (built via Kiro SDD — see .kiro/specs/rate-limiter/).

Per-client limit using a sliding window log. Uses Redis sorted sets when REDIS_URL
is set (shared across instances), otherwise an in-process store. Health/metrics are
exempt. Fails open on internal error so throttling can never take the API down.
"""
from __future__ import annotations

import hashlib
import os
import threading
import time
from collections import defaultdict, deque
from typing import Deque, Dict, Tuple

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse

EXEMPT_PATHS = {"/health", "/metrics"}


def _cfg() -> Tuple[int, float, bool]:
    return (int(os.getenv("RATE_LIMIT_MAX", "60")),
            float(os.getenv("RATE_LIMIT_WINDOW_S", "60")),
            os.getenv("RATE_LIMIT_ENABLED", "true").lower() in ("1", "true", "yes"))


# ------------------------------- stores ------------------------------------ #
class InMemoryStore:
    """dict[key] -> deque[timestamp]; sliding window under a lock."""

    def __init__(self) -> None:
        self._d: Dict[str, Deque[float]] = defaultdict(deque)
        self._lock = threading.Lock()

    def hit(self, key: str, now: float, window: float, max_: int) -> Tuple[bool, int, float]:
        with self._lock:
            dq = self._d[key]
            cutoff = now - window
            while dq and dq[0] <= cutoff:
                dq.popleft()
            count = len(dq)
            if count < max_:
                dq.append(now)
                remaining = max_ - count - 1
                reset = (dq[0] + window) if dq else (now + window)
                return True, remaining, reset
            reset = dq[0] + window
            return False, 0, reset


class RedisStore:
    """Sorted-set sliding window shared across instances."""

    def __init__(self, url: str) -> None:
        import redis  # imported lazily; optional dependency
        self._r = redis.Redis.from_url(url, socket_connect_timeout=0.5,
                                        socket_timeout=0.5, decode_responses=True)
        self._r.ping()  # surface connection errors now → caller falls back

    def hit(self, key: str, now: float, window: float, max_: int) -> Tuple[bool, int, float]:
        rk = f"ratelimit:{key}"
        cutoff = now - window
        pipe = self._r.pipeline()
        pipe.zremrangebyscore(rk, 0, cutoff)
        pipe.zcard(rk)
        pipe.zrange(rk, 0, 0, withscores=True)
        _, count, oldest = pipe.execute()
        if count < max_:
            p2 = self._r.pipeline()
            p2.zadd(rk, {f"{now:.6f}": now})
            p2.expire(rk, int(window) + 1)
            p2.execute()
            oldest_ts = oldest[0][1] if oldest else now
            return True, max_ - count - 1, oldest_ts + window
        oldest_ts = oldest[0][1] if oldest else now
        return False, 0, oldest_ts + window


def _build_store():
    url = os.getenv("REDIS_URL")
    if url:
        try:
            return RedisStore(url), "redis"
        except Exception:
            pass  # fall through to in-memory
    return InMemoryStore(), "memory"


# ------------------------------- middleware -------------------------------- #
def _client_key(request: Request) -> str:
    auth = request.headers.get("authorization")
    if auth:
        return "tok:" + hashlib.sha1(auth.encode()).hexdigest()[:16]
    host = request.client.host if request.client else "unknown"
    return "ip:" + host


class RateLimitMiddleware(BaseHTTPMiddleware):
    def __init__(self, app, store=None):
        super().__init__(app)
        built, backend = (store, "custom") if store is not None else _build_store()
        self.store = built
        self.backend = backend

    async def dispatch(self, request: Request, call_next):
        max_, window, enabled = _cfg()
        if not enabled or request.url.path in EXEMPT_PATHS:
            return await call_next(request)
        try:
            now = time.time()
            allowed, remaining, reset = self.store.hit(_client_key(request), now, window, max_)
        except Exception:
            return await call_next(request)  # fail open — never take the API down
        reset_epoch = int(reset)
        if not allowed:
            retry = max(1, reset_epoch - int(time.time()))
            return JSONResponse(
                status_code=429,
                content={"detail": "Rate limit exceeded. Try again later.",
                         "limit": max_, "window_seconds": int(window)},
                headers={"X-RateLimit-Limit": str(max_),
                         "X-RateLimit-Remaining": "0",
                         "X-RateLimit-Reset": str(reset_epoch),
                         "Retry-After": str(retry)})
        resp = await call_next(request)
        resp.headers["X-RateLimit-Limit"] = str(max_)
        resp.headers["X-RateLimit-Remaining"] = str(max(0, remaining))
        resp.headers["X-RateLimit-Reset"] = str(reset_epoch)
        return resp


def install_rate_limiter(app) -> None:
    """Attach the limiter unless disabled. Call right after CORS in api_server."""
    if os.getenv("RATE_LIMIT_ENABLED", "true").lower() in ("1", "true", "yes"):
        app.add_middleware(RateLimitMiddleware)
