# START HERE — ProposalForge Pro (capstone)

This is the complete, validated project. Local checks all pass:
- `pytest tests` -> 48 passed, 4 deselected (live Groq tests, run on demand)
- UI Tests tab -> 48/48, coverage ~29%
- `python eval/eval_realdoc.py` -> 4/4 PASS

## Repo layout on GitHub (subfolder in your EY-Training repo)
```
EY-Training/
├─ .github/workflows/          <-- put the TWO workflow files here (repo ROOT)
│  ├─ capstone-ci.yml
│  └─ capstone-azure.yml
└─ capstone/                    <-- everything from capstone.zip goes here
   ├─ src/ infra/ tests/ eval/ docs/ ...
   ├─ requirements.txt pytest.ini .gitignore .env.example .dockerignore
   └─ README.md DEPLOY_RUNBOOK.md
```
IMPORTANT: GitHub Actions only runs workflows at the REPO ROOT `.github/workflows/`,
NOT inside `capstone/`. The two workflow files are provided separately for that reason.
Delete any old `capstone/.github/` folder.

## Get CI green (tests)
1. Replace the `capstone/` folder contents with this zip.
2. Put `capstone-ci.yml` and `capstone-azure.yml` in the repo-root `.github/workflows/`.
3. Commit to `main`. The `test` job runs `pytest tests` -> 48 passed, 4 deselected.

## Deploy (no service principal needed)
Set these as REPOSITORY secrets (Settings -> Secrets and variables -> Actions):
- ACR_NAME, ACR_USERNAME, ACR_PASSWORD   (ACR -> Access keys, enable Admin user)
- AZURE_WEBAPP_PUBLISH_PROFILE           (Web App -> Download publish profile)
Load-test host is hardcoded to proposalforge-app.azurewebsites.net in the workflow;
change it there if your app name differs.

## Make it production (config only — see docs/MAKE_STATUS_GREEN.md)
On the Web App -> Environment variables, add what you want:
- LLM (selector + failover): CLAUDE_API_KEY and/or GROQ_API_KEY
- Vector DB: PINECONE_API_KEY, PINECONE_INDEX=proposalforge, VECTOR_BACKEND=auto
             EMBEDDING_MODEL=BAAI/bge-small-en-v1.5   (Pinecone index dimension = 384)
- Observability: APPLICATIONINSIGHTS_CONNECTION_STRING
- WEBSITES_PORT=8080, Web sockets = On, SESSION_TTL_SECONDS=3600
Then app -> Tests tab -> Refresh status should show green.

## Update — agentic build (capstone1)
- **Agent framework:** LangGraph now orchestrates the pipeline
  (Route → Guardrails → Retrieve → Generate → Suggest) in `src/orchestrator/graph.py`;
  the Engine runs it via `ask_graph()`.
- **Chatbot:** greets with "Hey! How can I help you today?" and shows **follow-up
  questions based on your last question** (LLM-driven when an online key is set).
- **Online LLM:** chat and pipeline show a clear warning when no online key is set,
  instead of silently assuming offline output. Set CLAUDE_API_KEY or GROQ_API_KEY.
- **Diagram-aware analysis:** upload PDFs/images and tick "scan diagrams, charts &
  visualizations". Uses Azure Document Intelligence (text/tables/figures) when
  AZURE_DOCINTEL_ENDPOINT/KEY are set, and describes diagrams/graphs via Claude vision
  when CLAUDE_API_KEY is set. See `src/common/doc_analysis.py`.
- **Removed:** human approval tab and login/session (REQUIRE_AUTH defaults to false).
- New deps: langgraph, azure-ai-documentintelligence, pymupdf (see requirements.txt).
