# Requirements: API Rate Limiter Middleware

> Spec-Driven Development (SDD) — Phase 1 of 3: **Requirements Gathering**
> Feature: protect the ProposalForge FastAPI from abuse and runaway cost with a
> per-client sliding-window rate limit.
> Status: ✅ Approved — proceed to `design.md`.

## Context & Intent
The public API (`src/api/api_server.py`) exposes LLM-backed endpoints
(`/api/v1/pipeline/run`, `/api/v1/retrieve`, document upload/query, …). Without
throttling, a single client can exhaust the LLM quota and degrade the service
for everyone. We need a transparent, standards-compliant rate limiter.

## Requirements & Behavioral Logic

### Requirement 1: Per-client sliding-window limit
**User Story:** As an API operator, I want each client capped to N requests per
rolling window, so that no single caller can monopolise the service or budget.

#### Acceptance Criteria (EARS)
- WHEN a client makes a request AND it has made fewer than `RATE_LIMIT_MAX`
  requests within the last `RATE_LIMIT_WINDOW_S` seconds, THEN the system SHALL
  allow the request and process it normally.
- WHEN a client exceeds `RATE_LIMIT_MAX` requests within the rolling window,
  THEN the system SHALL reject the request with HTTP **429 Too Many Requests**.
- WHEN the oldest request in a client's window ages past `RATE_LIMIT_WINDOW_S`,
  THEN the system SHALL no longer count it (true sliding window, not fixed).

### Requirement 2: Client identification
**User Story:** As an operator, I want authenticated callers tracked by identity
and anonymous callers tracked by IP, so limits are fair and hard to evade.

#### Acceptance Criteria (EARS)
- WHEN a request carries an `Authorization` header, THEN the system SHALL derive
  the client key from that token.
- IF no `Authorization` header is present, THEN the system SHALL fall back to the
  client IP address as the key.

### Requirement 3: Standard rate-limit headers
**User Story:** As an API consumer, I want to see my remaining quota so I can
back off gracefully.

#### Acceptance Criteria (EARS)
- WHEN the system allows a request, THEN the response SHALL include
  `X-RateLimit-Limit`, `X-RateLimit-Remaining`, and `X-RateLimit-Reset`.
- WHEN the system rejects a request with 429, THEN the response SHALL additionally
  include a `Retry-After` header (seconds until capacity frees up).

### Requirement 4: Health & metrics must never be throttled
**User Story:** As a platform engineer, I want liveness and metrics probes exempt,
so load balancers, uptime checks and the load-test harness are never rate-limited.

#### Acceptance Criteria (EARS)
- WHEN the request path is `/health` or `/metrics`, THEN the system SHALL bypass
  the rate limiter entirely.

### Requirement 5: Durable-optional backend with safe fallback
**User Story:** As an operator running multiple instances, I want a shared counter
when Redis is available, but the API must still work without it.

#### Acceptance Criteria (EARS)
- IF `REDIS_URL` is configured AND reachable, THEN the system SHALL store request
  timestamps in Redis so the limit is shared across instances.
- IF Redis is not configured OR unreachable, THEN the system SHALL fall back to an
  in-process store and continue enforcing the limit locally (never crash).

## Kiro Quality Gate 1
> Code generation paused. Operator verified edge cases: window boundary parity
> (a request exactly `WINDOW_S` old is excluded), missing-header fallback to IP,
> and exempt-path bypass. **Approved → generate technical design.**
