# Task List: API Rate Limiter Middleware

> SDD — Phase 3 of 3: **Task Breakdown & Execution**
> Derived from `design.md`. Executed via "Run All Tasks". States transition
> `[ ]` → `[x]` as each task's Definition of Done (DoD) clears.

## Wave 1 — Core (no dependencies)
- [x] **Task 1: Store interface + in-memory sliding-window store**
  - Implement `LimitStore.hit()` and `InMemoryStore` (deque + lock) in
    `src/api/rate_limiter.py`.
  - *DoD:* unit test — 5th request blocked when max=4; entry older than the
    window is evicted and frees capacity.

- [x] **Task 2: Redis sorted-set store (optional, shared)**
  - Implement `RedisStore` using `ZREMRANGEBYSCORE`/`ZCARD`/`ZADD`/`EXPIRE` in a
    pipeline; construct only when `REDIS_URL` is set.
  - *DoD:* import-safe without `redis` installed; falls back to in-memory on any
    connection error (covered by a monkeypatched failure test).

## Wave 2 — Middleware (depends on Wave 1)
- [x] **Task 3: `RateLimitMiddleware` (Starlette BaseHTTPMiddleware)**
  - Key derivation (token→hash / IP), exempt paths, 429 response, header
    injection on both allow and deny paths, fail-open on internal error.
  - *DoD:* integration test — 429 after the cap; `X-RateLimit-Limit`,
    `X-RateLimit-Remaining`, `X-RateLimit-Reset`, `Retry-After` present.

- [x] **Task 4: Wire into the API**
  - `install_rate_limiter(app)` called right after CORS in `api_server.py`;
    honour `RATE_LIMIT_ENABLED`.
  - *DoD:* `/health` and `/metrics` never throttled; other endpoints are.

## Wave 3 — Verify & document (depends on Wave 2)
- [x] **Task 5: Tests + config docs**
  - Add `tests/test_rate_limiter.py`; document env vars in `.env.example`;
    add `redis` (optional) to `requirements.txt`.
  - *DoD:* full suite green; new tests included; docs updated.

## Execution log
```
[x] Task 1  in-memory store .......... unit tests pass
[x] Task 2  redis store .............. import-safe + fallback verified
[x] Task 3  middleware ............... 429 + headers verified (TestClient)
[x] Task 4  wired into api_server .... exempt paths bypass confirmed
[x] Task 5  tests + docs ............. suite green
All tasks checked off ✅
```
