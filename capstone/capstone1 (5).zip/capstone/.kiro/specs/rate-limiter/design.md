# Technical Design: API Rate Limiter Middleware

> SDD — Phase 2 of 3: **Technical Design**
> Derived from `requirements.md`. Status: ✅ Approved — proceed to `tasks.md`.

## Algorithm — Sliding Window Log (Redis sorted sets)
Per the playbook's steering guidance, we use a **sliding window log** rather than a
fixed window, to preserve transaction accuracy at window boundaries.

For each client key we keep a time-ordered set of request timestamps:
- **Redis backend:** a sorted set `ratelimit:{key}` with `score = timestamp`.
  1. `ZREMRANGEBYSCORE key 0 (now - window)` → evict expired entries.
  2. `ZCARD key` → current count in window.
  3. If `count < max`: `ZADD key now now` and `EXPIRE key window`.
  4. `allowed = count < max`, `remaining = max - count - 1`,
     `reset = oldest_ts + window`.
  Steps run in a `MULTI/EXEC` pipeline for atomicity.
- **In-memory fallback:** `dict[key] -> deque[float]`; drop timestamps older than
  `now - window`, then apply the same count/append logic under a lock.

Both backends implement one interface:

```
class LimitStore(Protocol):
    def hit(self, key: str, now: float, window: float, max_: int)
        -> tuple[bool, int, float]   # (allowed, remaining, reset_epoch)
```

## Client key derivation
```
auth = request.headers.get("authorization")
key  = "tok:" + sha1(auth)[:16]  if auth else "ip:" + request.client.host
```
Tokens are hashed so raw credentials never become dict/Redis keys or logs.

## Middleware placement (`src/api/rate_limiter.py`)
A Starlette `BaseHTTPMiddleware` subclass `RateLimitMiddleware`:
1. If `request.url.path` in `EXEMPT_PATHS` (`/health`, `/metrics`) → `call_next`.
2. Compute key; call `store.hit(...)`.
3. If not allowed → return `JSONResponse(status_code=429, ...)` with
   `Retry-After` + the three `X-RateLimit-*` headers.
4. Else → `resp = await call_next(request)`, attach `X-RateLimit-*` headers, return.

Wired in `api_server.py` immediately after the CORS middleware via
`install_rate_limiter(app)`.

## Configuration (env, with defaults)
| Var | Default | Meaning |
|-----|---------|---------|
| `RATE_LIMIT_MAX` | `60` | requests allowed per window per client |
| `RATE_LIMIT_WINDOW_S` | `60` | rolling window length (seconds) |
| `RATE_LIMIT_ENABLED` | `true` | master on/off switch |
| `REDIS_URL` | *(unset)* | enables the shared Redis backend |

## Error Boundary Handling
- Any Redis error (connect/timeout) is caught once, logged as a warning, and the
  limiter transparently switches to the in-memory store for the process lifetime.
- A malformed/absent client host defaults the key to `ip:unknown` (still limited).
- The limiter never raises into the request path; on unexpected internal error it
  **fails open** (allows the request) so throttling can't take the API down.

## Test Strategy (maps to tasks)
- Unit: in-memory store allows N then blocks the (N+1)th; boundary entry expiry.
- Integration (FastAPI `TestClient`): 429 after the cap; `X-RateLimit-*` +
  `Retry-After` headers present; `/health` never limited.
