# Task List: Bid / No-Bid Scoring Agent

> SDD — Phase 3 of 3: **Task Breakdown & Execution**
> Derived from `design.md`. States flip `[ ]` → `[x]` as each DoD clears.

## Wave 1 — Scoring core (no dependencies)
- [x] **Task 1: Data model + weight normalisation**
  - `BidResult` dataclass; `DEFAULT_WEIGHTS`; `_normalise()`.
  - *DoD:* weights with negatives/!=1 sum normalise to sum 1; equal-weight
    fallback when total is 0.
- [x] **Task 2: `score_bid(scores, weights=None)`**
  - Clamp 0–100, default missing to 50, weighted sum, threshold → recommendation,
    breakdown, templated rationale.
  - *DoD:* unit tests — high→BID, low→NO-BID, mid→REVIEW; boundary 70→BID,
    45→REVIEW; breakdown sums to total.

## Wave 2 — Opportunity analyzer (depends on Wave 1)
- [x] **Task 3: `analyze_opportunity(text, llm=None)`**
  - Deterministic signal detection → suggested scores + signals + detected domain;
    optional LLM rationale (never required).
  - *DoD:* same text twice → identical suggestion; all suggested scores in 0–100;
    seeded opportunity yields ≥1 signal.

## Wave 3 — Exposure (depends on Wave 2)
- [x] **Task 4: API endpoint**
  - `POST /api/v1/bid/score` in `api_server.py` (accepts scores OR text OR both).
  - *DoD:* returns score, recommendation, breakdown, rationale, signals.
- [x] **Task 5: UI tab + audit**
  - "🎯 Bid / No-Bid" tab in `app_prod.py`: sliders / paste-opportunity, gauge,
    recommendation badge, breakdown chart, rationale; logs `BID_SCORE` to audit.
  - *DoD:* app runs end-to-end (Streamlit AppTest) with no exception.

## Wave 4 — Verify (depends on Wave 3)
- [x] **Task 6: Tests**
  - `tests/test_bid_scoring.py` covering Waves 1–2.
  - *DoD:* full suite green.

## Execution log
```
[x] Task 1  model + normalise ........ unit tests pass
[x] Task 2  score_bid ................ thresholds + breakdown verified
[x] Task 3  analyze_opportunity ...... deterministic + signals verified
[x] Task 4  API /api/v1/bid/score .... returns full payload
[x] Task 5  UI tab + audit ........... AppTest: no exception
[x] Task 6  tests .................... suite green
All tasks checked off ✅
```
