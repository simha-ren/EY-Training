# Technical Design: Bid / No-Bid Scoring Agent

> SDD — Phase 2 of 3: **Technical Design**
> Derived from `requirements.md`. Status: ✅ Approved — proceed to `tasks.md`.

## Module
`src/agents/bid_scoring.py` — pure-Python, dependency-free scoring core plus an
optional deterministic text analyzer. No API key required.

## Criteria & default weights
| Criterion | Key | Weight | Higher score means |
|---|---|---|---|
| Solution fit | `solution_fit` | 0.30 | our capabilities match the requirement |
| Win probability | `win_probability` | 0.25 | strong competitive position |
| Strategic value | `strategic_value` | 0.20 | aligns with our goals / growth |
| Feasibility | `feasibility` | 0.15 | deliverable within effort/timeline |
| Risk profile | `risk_profile` | 0.10 | **low** risk (already inverted) |

`risk_profile` is expressed so that a higher number is better (low risk), keeping
the weighted sum monotonic — the caller scores "how good is the risk picture".

## Data model
```python
@dataclass
class BidResult:
    score: float                 # 0-100 weighted total
    recommendation: str          # "BID" | "REVIEW" | "NO-BID"
    breakdown: Dict[str, float]  # per-criterion weighted contribution
    weights: Dict[str, float]    # normalised weights actually used
    rationale: str               # names strongest & weakest criteria
    signals: List[str]           # detected opportunity signals (if text analysed)
```

## Scoring algorithm
1. `w = normalise(weights or DEFAULT_WEIGHTS)` — clamp negatives to 0, divide by sum.
2. For each criterion: `s = clamp(scores.get(k, 50), 0, 100)`.
3. `breakdown[k] = round(s * w[k], 2)`; `total = round(sum(breakdown), 2)`.
4. `recommendation`: `BID` if `total ≥ 70`, `NO-BID` if `total < 45`, else `REVIEW`.
5. `rationale`: template naming the highest- and lowest-contributing criteria and
   the recommendation (e.g. "Strong solution fit; weakest area is feasibility.").

## Thresholds (module constants, tunable)
`BID_THRESHOLD = 70.0`, `NOBID_THRESHOLD = 45.0`.

## Deterministic opportunity analysis — `analyze_opportunity(text, llm=None)`
Baseline every criterion at 50, then nudge ±up-to-25 from regex/keyword signals:
- **Budget stated** (`$`, "budget", "funding") → +win, +feasibility; add signal.
- **Tight deadline** ("within N days", "deadline", "urgent") → −feasibility.
- **Mandatory certifications** ("must", "mandatory", "ISO", "SOC 2", "HIPAA") →
  −solution_fit unless matched, +risk-awareness signal.
- **Incumbent mentioned** ("incumbent", "renewal", "existing vendor") → −win.
- **Scope clarity** (length & presence of "scope"/"requirements") → +/− solution_fit.
- **Domain fit** (Finance/Healthcare/Agriculture keywords) → +strategic_value,
  +solution_fit; records the detected domain as a signal.
Returns `{"suggested_scores": {..0-100..}, "signals": [str, ...],
"detected_domain": str}`. Pure function → identical output for identical input.
If `llm` is online, it MAY replace `rationale` with a richer sentence, but scores
stay deterministic.

## Exposure
- **API:** `POST /api/v1/bid/score` in `api_server.py` accepts `{scores?, text?,
  weights?}`; if only `text` is given it runs `analyze_opportunity` first.
- **UI:** a "🎯 Bid / No-Bid" tab in `app_prod.py` with either 5 sliders or a
  paste-the-opportunity box → shows score gauge, recommendation badge, breakdown
  bar chart and rationale; logs a `BID_SCORE` entry to the audit log.

## Error boundaries
- Non-numeric / missing scores → neutral 50. Out-of-range → clamped 0–100.
- Empty/whitespace text → all-50 suggestion with an empty signals list.
- Weights summing to 0 → fall back to equal weights. Never raises.

## Test strategy (maps to tasks)
- Unit: high→BID, low→NO-BID, mid→REVIEW; boundary 70/45; weight normalisation;
  breakdown sums to total; clamping; missing keys → 50.
- Analyzer: deterministic (same text twice → equal); scores in 0–100; signals
  detected for a seeded opportunity string.
