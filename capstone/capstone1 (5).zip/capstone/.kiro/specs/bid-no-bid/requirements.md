# Requirements: Bid / No-Bid Scoring Agent

> Spec-Driven Development (SDD) — Phase 1 of 3: **Requirements Gathering**
> Feature: given a proposal opportunity, recommend whether to pursue it (BID),
> hold for review (REVIEW), or decline (NO-BID), with an explainable score.
> Status: ✅ Approved — proceed to `design.md`.

## Context & Intent
ProposalForge helps teams respond to opportunities across Finance, Healthcare and
Agriculture. Before writing a proposal, a team must decide **whether to bid at
all**. This feature turns that judgement into a transparent, weighted score so the
decision is consistent, defensible and fast.

## Requirements & Behavioral Logic

### Requirement 1: Weighted multi-criteria score
**User Story:** As a proposal lead, I want an opportunity scored across standard
criteria so I get a single, comparable Bid score.

#### Acceptance Criteria (EARS)
- WHEN criterion scores (0–100) are provided for solution fit, win probability,
  strategic value, feasibility and risk profile, THEN the system SHALL compute a
  weighted total in the range 0–100.
- WHEN no weights are supplied, THEN the system SHALL use the default weights.
- WHEN custom weights are supplied, THEN the system SHALL normalise them to sum
  to 1 before scoring.
- WHEN any criterion score is missing, THEN the system SHALL default that
  criterion to a neutral 50.

### Requirement 2: Clear recommendation with thresholds
**User Story:** As a lead, I want a plain recommendation, not just a number.

#### Acceptance Criteria (EARS)
- WHEN the total score ≥ 70, THEN the system SHALL recommend **BID**.
- IF the total score is between 45 and 69 inclusive, THEN the system SHALL
  recommend **REVIEW**.
- WHEN the total score < 45, THEN the system SHALL recommend **NO-BID**.

### Requirement 3: Explainability
**User Story:** As a lead, I need to justify the decision to stakeholders.

#### Acceptance Criteria (EARS)
- WHEN a score is produced, THEN the system SHALL return the per-criterion
  weighted contribution (breakdown) and a short natural-language rationale that
  names the strongest and weakest criteria.

### Requirement 4: Optional opportunity auto-analysis
**User Story:** As a lead, I want to paste the opportunity text and get suggested
scores, so I don't start from a blank slate.

#### Acceptance Criteria (EARS)
- WHEN opportunity text is provided instead of scores, THEN the system SHALL
  derive suggested criterion scores (0–100) from detectable signals (budget,
  deadline, mandatory certifications, incumbent, scope clarity, domain fit) and
  SHALL return the list of signals it detected.
- The auto-analysis SHALL be deterministic (same text → same suggestion) and
  SHALL NOT require any API key; an online LLM MAY refine the rationale when
  available but SHALL never be required.

### Requirement 5: Never crash
#### Acceptance Criteria (EARS)
- WHEN inputs are malformed, empty or out of range, THEN the system SHALL clamp
  or default them and still return a valid result (no exception to the caller).

## Kiro Quality Gate 1
> Code generation paused. Operator verified edge cases: empty input → neutral 50s,
> weights that don't sum to 1 → normalised, out-of-range scores → clamped 0–100,
> boundary thresholds (exactly 70 → BID, exactly 45 → REVIEW).
> **Approved → generate technical design.**
