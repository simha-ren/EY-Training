#!/usr/bin/env python3
"""Production smoke test for ProposalForge Agent.

Exercises the LIVE deployment end-to-end and prints a PASS/FAIL report:

  1.  Liveness         GET  /health              (with cold-start retry)
  2.  Metrics          GET  /metrics
  3.  System wiring    GET  /api/v1/status        (LLM connector, vector DB,
                                                    tracing / Azure Monitor)
  4.  Bid / No-Bid     POST /api/v1/bid/score     (from opportunity text)
  5.  Bid (manual)     POST /api/v1/bid/score     (explicit criterion scores)
  6.  Compliance       POST /api/v1/compliance/matrix
  7.  Rate limiter     rapid calls -> expect HTTP 429 + X-RateLimit-* headers
                                       and /health stays exempt   (--rate-limit-check)
  8.  Latency          single-call timings for key endpoints

Exit code is non-zero if any *critical* check fails, so it drops straight into
CI / a post-deploy gate.

Usage
-----
  python production_smoke_test.py --base-url https://YOURAPP.azurewebsites.net
  BASE_URL=https://YOURAPP.azurewebsites.net python production_smoke_test.py \
      --rate-limit-check --json smoke_report.json

Zero third-party dependencies (standard library only).
"""
from __future__ import annotations

import argparse
import json
import os
import ssl
import sys
import time
import urllib.error
import urllib.request
from datetime import datetime, timezone

DEFAULT_BASE = os.getenv("BASE_URL", "https://proposalforge-app.azurewebsites.net")
TIMEOUT = float(os.getenv("SMOKE_TIMEOUT", "30"))


# ------------------------------- pretty output ---------------------------- #
def _use_colour() -> bool:
    return sys.stdout.isatty() and os.getenv("NO_COLOR") is None


_C = _use_colour()
GRN = "\033[32m" if _C else ""
RED = "\033[31m" if _C else ""
YEL = "\033[33m" if _C else ""
CYN = "\033[36m" if _C else ""
DIM = "\033[2m" if _C else ""
BLD = "\033[1m" if _C else ""
RST = "\033[0m" if _C else ""
ICON = {"PASS": f"{GRN}PASS{RST}", "FAIL": f"{RED}FAIL{RST}",
        "WARN": f"{YEL}WARN{RST}", "SKIP": f"{DIM}SKIP{RST}"}


# ------------------------------- http helper ------------------------------ #
def http(method, url, body=None, headers=None, timeout=TIMEOUT, insecure=False):
    """Return (status, headers, text, elapsed_ms). Raises on connection error."""
    data = json.dumps(body).encode() if body is not None else None
    h = {"Content-Type": "application/json", "Accept": "application/json",
         "User-Agent": "ProposalForge-SmokeTest/1.0"}
    if headers:
        h.update(headers)
    req = urllib.request.Request(url, data=data, headers=h, method=method)
    ctx = ssl.create_default_context()
    if insecure:
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
    t0 = time.perf_counter()
    try:
        with urllib.request.urlopen(req, timeout=timeout, context=ctx) as r:
            text = r.read().decode("utf-8", "replace")
            return r.status, {k.lower(): v for k, v in r.headers.items()}, text, \
                (time.perf_counter() - t0) * 1000
    except urllib.error.HTTPError as e:
        text = e.read().decode("utf-8", "replace") if e.fp else ""
        return e.code, {k.lower(): v for k, v in (e.headers or {}).items()}, text, \
            (time.perf_counter() - t0) * 1000


# ------------------------------- runner ----------------------------------- #
class Runner:
    def __init__(self, base, insecure=False):
        self.base = base.rstrip("/")
        self.insecure = insecure
        self.results = []

    def record(self, name, status, ms=0.0, detail="", critical=True):
        self.results.append({"name": name, "status": status, "ms": round(ms, 1),
                             "detail": detail, "critical": critical})
        line = f"  {ICON[status]}  {BLD}{name}{RST}"
        if ms:
            line += f"  {DIM}{ms:,.0f} ms{RST}"
        if detail:
            line += f"\n         {DIM}{detail}{RST}"
        print(line)

    def url(self, path):
        return self.base + path

    def get(self, path, **kw):
        return http("GET", self.url(path), insecure=self.insecure, **kw)

    def post(self, path, body, **kw):
        return http("POST", self.url(path), body=body, insecure=self.insecure, **kw)

    # ------------------------------ checks -------------------------------- #
    def check_health(self, retries=6):
        """Liveness with cold-start retry/backoff."""
        last = ""
        for attempt in range(1, retries + 1):
            try:
                st, _, text, ms = self.get("/health", timeout=TIMEOUT)
                if st == 200:
                    self.record("Liveness (/health)", "PASS", ms,
                                f"200 OK on attempt {attempt}")
                    return True
                last = f"HTTP {st}: {text[:80]}"
            except Exception as e:
                last = f"{type(e).__name__}: {e}"
            if attempt < retries:
                wait = min(2 ** attempt, 15)
                print(f"         {DIM}warming up… retry {attempt}/{retries-1} "
                      f"in {wait}s ({last}){RST}")
                time.sleep(wait)
        self.record("Liveness (/health)", "FAIL", 0, f"unreachable — {last}")
        return False

    def check_metrics(self):
        try:
            st, _, _, ms = self.get("/metrics")
            self.record("Metrics (/metrics)", "PASS" if st == 200 else "FAIL", ms,
                        f"HTTP {st}", critical=False)
        except Exception as e:
            self.record("Metrics (/metrics)", "FAIL", 0, str(e), critical=False)

    def check_status(self):
        try:
            st, _, text, ms = self.get("/api/v1/status")
            if st != 200:
                self.record("System status", "FAIL", ms, f"HTTP {st}: {text[:80]}")
                return
            data = json.loads(text)
            llm = (data.get("llm") or {}).get("backend", "?")
            vdb = (data.get("vector_db") or {}).get("backend", "?")
            trace = (data.get("tracing") or {}).get("provider", "?")
            azmon = (data.get("observability") or {}).get("azure_monitor", False)
            self.record("System status (/api/v1/status)", "PASS", ms,
                        f"llm={llm} · vector_db={vdb} · tracing={trace} · "
                        f"azure_monitor={'on' if azmon else 'off'}")
            # sub-assertions (non-fatal warnings)
            if llm == "offline":
                self.record("LLM connector is live", "WARN", 0,
                            "backend=offline — set CLAUDE_API_KEY / GROQ_API_KEY",
                            critical=False)
            else:
                self.record("LLM connector is live", "PASS", 0, f"backend={llm}",
                            critical=False)
            if vdb in ("pinecone", "pgvector", "qdrant"):
                self.record("Vector DB is production-grade", "PASS", 0, f"{vdb}",
                            critical=False)
            elif vdb in ("faiss", "tfidf"):
                self.record("Vector DB is production-grade", "WARN", 0,
                            f"using fallback '{vdb}' — set PINECONE_API_KEY",
                            critical=False)
            else:
                self.record("Vector DB is production-grade", "WARN", 0,
                            f"backend={vdb}", critical=False)
            if azmon:
                self.record("Azure Monitor tracing", "PASS", 0, "connected",
                            critical=False)
            else:
                self.record("Azure Monitor tracing", "WARN", 0,
                            "off — set APPLICATIONINSIGHTS_CONNECTION_STRING",
                            critical=False)
        except Exception as e:
            self.record("System status (/api/v1/status)", "FAIL", 0, str(e))

    def check_bid_text(self):
        body = {"text": "Healthcare RFP with a $2M budget, mandatory HIPAA "
                        "compliance, strategic long-term partnership, scope "
                        "defined, deadline within 30 days."}
        try:
            st, _, text, ms = self.post("/api/v1/bid/score", body)
            d = json.loads(text) if st == 200 else {}
            ok = st == 200 and d.get("recommendation") in ("BID", "REVIEW", "NO-BID") \
                and 0 <= float(d.get("score", -1)) <= 100
            self.record("Bid/No-Bid from text", "PASS" if ok else "FAIL", ms,
                        (f"{d.get('recommendation')} · score {d.get('score')} · "
                         f"domain {d.get('detected_domain')}") if ok
                        else f"HTTP {st}: {text[:80]}")
        except Exception as e:
            self.record("Bid/No-Bid from text", "FAIL", 0, str(e))

    def check_bid_manual(self):
        body = {"scores": {"solution_fit": 90, "win_probability": 85,
                           "strategic_value": 80, "feasibility": 75,
                           "risk_profile": 70}}
        try:
            st, _, text, ms = self.post("/api/v1/bid/score", body)
            d = json.loads(text) if st == 200 else {}
            ok = st == 200 and d.get("recommendation") in ("BID", "REVIEW", "NO-BID")
            self.record("Bid/No-Bid from scores", "PASS" if ok else "FAIL", ms,
                        (f"{d.get('recommendation')} · score {d.get('score')}")
                        if ok else f"HTTP {st}: {text[:80]}", critical=False)
        except Exception as e:
            self.record("Bid/No-Bid from scores", "FAIL", 0, str(e), critical=False)

    def check_compliance(self):
        body = {
            "rfp_text": ("The system shall encrypt all data at rest.\n"
                         "The vendor must provide 24/7 support.\n"
                         "- Export audit logs in CSV format"),
            "response_text": ("Our platform encrypts all data at rest with AES-256 "
                              "and exports audit logs in CSV format."),
        }
        try:
            st, _, text, ms = self.post("/api/v1/compliance/matrix", body)
            d = json.loads(text) if st == 200 else {}
            s = d.get("summary", {})
            ok = st == 200 and "compliance_pct" in s and len(d.get("rows", [])) >= 2
            self.record("Compliance matrix", "PASS" if ok else "FAIL", ms,
                        (f"{s.get('compliance_pct')}% compliant · "
                         f"{s.get('covered')}/{s.get('total')} covered · "
                         f"{s.get('missing')} missing") if ok
                        else f"HTTP {st}: {text[:80]}")
        except Exception as e:
            self.record("Compliance matrix", "FAIL", 0, str(e))

    def check_rate_limit(self, max_attempts=80):
        """Rapid-fire a non-exempt endpoint; expect a 429 with headers."""
        got_429 = False
        headers_ok = False
        n = 0
        try:
            for n in range(1, max_attempts + 1):
                st, hdr, _, _ = self.get("/api/v1/status", timeout=TIMEOUT)
                if st == 429:
                    got_429 = True
                    headers_ok = "x-ratelimit-limit" in hdr and "retry-after" in hdr
                    break
            if got_429:
                # confirm health is exempt even while limited
                hst, _, _, _ = self.get("/health")
                exempt = hst == 200
                detail = (f"429 after {n} requests · headers "
                          f"{'present' if headers_ok else 'MISSING'} · "
                          f"/health exempt={'yes' if exempt else 'NO'}")
                status = "PASS" if (headers_ok and exempt) else "WARN"
                self.record("Rate limiter enforces 429", status, 0, detail,
                            critical=False)
            else:
                self.record("Rate limiter enforces 429", "WARN", 0,
                            f"no 429 in {max_attempts} requests — limit may be high "
                            "or disabled (RATE_LIMIT_MAX / RATE_LIMIT_ENABLED)",
                            critical=False)
        except Exception as e:
            self.record("Rate limiter enforces 429", "WARN", 0, str(e), critical=False)

    def check_latency(self):
        for label, path in (("/health", "/health"), ("/api/v1/status", "/api/v1/status")):
            try:
                _, _, _, ms = self.get(path)
                status = "PASS" if ms < 3000 else "WARN"
                self.record(f"Latency {label}", status, ms,
                            "under 3s" if ms < 3000 else "slow (>3s) — cold start?",
                            critical=False)
            except Exception as e:
                self.record(f"Latency {label}", "WARN", 0, str(e), critical=False)


# ------------------------------- main ------------------------------------- #
def main():
    ap = argparse.ArgumentParser(description="ProposalForge production smoke test")
    ap.add_argument("--base-url", default=DEFAULT_BASE,
                    help="Deployment base URL (or set BASE_URL)")
    ap.add_argument("--rate-limit-check", action="store_true",
                    help="Include the rate-limiter test (sends many rapid requests)")
    ap.add_argument("--json", metavar="PATH", help="Write a JSON report to PATH")
    ap.add_argument("--insecure", action="store_true",
                    help="Skip TLS certificate verification")
    args = ap.parse_args()

    print(f"\n{BLD}{CYN}ProposalForge Agent — Production Smoke Test{RST}")
    print(f"{DIM}Target : {args.base_url}{RST}")
    print(f"{DIM}Started: {datetime.now(timezone.utc).isoformat(timespec='seconds')}{RST}\n")

    r = Runner(args.base_url, insecure=args.insecure)

    print(f"{BLD}Core{RST}")
    alive = r.check_health()
    r.check_metrics()
    r.check_status()

    if alive:
        print(f"\n{BLD}Features{RST}")
        r.check_bid_text()
        r.check_bid_manual()
        r.check_compliance()
        if args.rate_limit_check:
            print(f"\n{BLD}Resilience{RST}")
            r.check_rate_limit()
        print(f"\n{BLD}Performance{RST}")
        r.check_latency()
    else:
        r.record("Feature checks", "SKIP", 0, "host not reachable", critical=False)

    # ---- summary ----
    total = len(r.results)
    passed = sum(1 for c in r.results if c["status"] == "PASS")
    failed = [c for c in r.results if c["status"] == "FAIL"]
    warned = sum(1 for c in r.results if c["status"] == "WARN")
    crit_fail = [c for c in failed if c["critical"]]

    print(f"\n{BLD}{'─'*54}{RST}")
    print(f"{BLD}Summary{RST}: {GRN}{passed} passed{RST}, "
          f"{RED}{len(failed)} failed{RST}, {YEL}{warned} warnings{RST} "
          f"(of {total} checks)")
    if crit_fail:
        print(f"{RED}{BLD}RESULT: FAIL{RST} — critical: "
              + ", ".join(c["name"] for c in crit_fail))
        verdict = "FAIL"
    elif failed:
        print(f"{YEL}{BLD}RESULT: PASS (with non-critical failures){RST}")
        verdict = "PASS_WITH_ISSUES"
    else:
        print(f"{GRN}{BLD}RESULT: PASS — production looks healthy ✅{RST}")
        verdict = "PASS"

    if args.json:
        report = {"base_url": args.base_url,
                  "timestamp": datetime.now(timezone.utc).isoformat(),
                  "verdict": verdict,
                  "summary": {"total": total, "passed": passed,
                              "failed": len(failed), "warnings": warned},
                  "checks": r.results}
        with open(args.json, "w") as f:
            json.dump(report, f, indent=2)
        print(f"{DIM}JSON report written to {args.json}{RST}")

    sys.exit(1 if crit_fail else 0)


if __name__ == "__main__":
    main()
